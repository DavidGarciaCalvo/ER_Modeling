DO
$do$
BEGIN
   IF NOT EXISTS (SELECT 1 FROM pg_namespace WHERE nspname = 'mydb') THEN
      CREATE SCHEMA mydb;
   END IF;
END
$do$;

SET search_path TO mydb;

CREATE TABLE IF NOT EXISTS Publisher (
  PublisherID SERIAL PRIMARY KEY,
  Name VARCHAR(255),
  Address VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Book (
  BookID SERIAL PRIMARY KEY,
  Title VARCHAR(255),
  Genre VARCHAR(255),
  Price INT,
  PublisherID INT,
  CONSTRAINT fk_Book_Publisher FOREIGN KEY (PublisherID)
    REFERENCES Publisher (PublisherID)
    ON DELETE SET NULL
    ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS Author (
  AuthorID SERIAL PRIMARY KEY,
  Name VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Customer (
  CustomerID SERIAL PRIMARY KEY,
  Name VARCHAR(255),
  Email VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS BookOrder (
  OrderID SERIAL PRIMARY KEY,
  CustomerID INT,
  OrderDate DATE,
  BookID INT,
  CONSTRAINT fk_Order_Customer FOREIGN KEY (CustomerID)
    REFERENCES Customer (CustomerID)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS OrderWithBook (
  OrderID INT NOT NULL,
  BookID INT NOT NULL,
  PRIMARY KEY (OrderID, BookID),
  CONSTRAINT fk_OrderWithBook_Order FOREIGN KEY (OrderID)
    REFERENCES BookOrder (OrderID)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_OrderWithBook_Book FOREIGN KEY (BookID)
    REFERENCES Book (BookID)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS BookWithAuthor (
  BookID INT NOT NULL,
  AuthorID INT NOT NULL,
  PRIMARY KEY (BookID, AuthorID),
  CONSTRAINT fk_BookWithAuthor_Book FOREIGN KEY (BookID)
    REFERENCES Book (BookID)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_BookAuthor_Author FOREIGN KEY (AuthorID)
    REFERENCES Author (AuthorID)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);



insert into Author (AuthorID, Name) VALUES 
(01, 'David Garcia'),
(02, 'J.K. Rawling');

insert into publisher (PublisherID, Name, Address) Values
(41, 'Hot Wheels', '123 Big Street, Poznan, POL'),
(42, 'Fantasy Books', '789 Big Street, Poznan, POL');

insert into book (BookID, Title, Genre, Price, PublisherID) Values
(11, 'Ford Mustang', 'Technical', 19.99, 41),
(12, 'Harry Potter Vol. I', 'Fantasy', 29.99, 42);

insert into customer (customerID, name, email) values
(21, 'David Garcia', 'davidgarcia@gmail.com'),
(22, 'Robert Lewandowski', 'rl9@gmail.com');

insert into bookOrder (OrderID, CustomerID, OrderDate, BookID) values
(31, 21, '2024-12-04', 11),
(32, 22, '2024-11-04', 12);

insert into orderWithBook (OrderID, BookID) values
(31, 11),
(32, 12);

insert into BookWithAuthor (BookID, AuthorID) values
(11, 01),
(12, 02);


